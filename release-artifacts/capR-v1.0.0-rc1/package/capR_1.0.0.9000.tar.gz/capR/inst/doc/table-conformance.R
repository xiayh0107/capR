## ----setup, include=FALSE-----------------------------------------------------
knitr::opts_chunk$set(collapse = TRUE, comment = "#>")

## -----------------------------------------------------------------------------
library(capR)
info <- cap_vendor_info()
verification <- cap_verify_vendor()
report <- cap_run_fixtures()

stopifnot(
  verification$ok,
  identical(info$tag, "cap-digest-v1.0.0"),
  report$ok,
  report$level == 3L,
  length(report$checks) == 5L
)
vapply(report$checks, `[[`, logical(1), "ok")

