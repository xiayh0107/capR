## ----setup, include=FALSE-----------------------------------------------------
knitr::opts_chunk$set(collapse = TRUE, comment = "#>")

## -----------------------------------------------------------------------------
library(capR)
info <- cap_vendor_info()
verification <- cap_verify_vendor()
report <- cap_run_fixtures()

if (!report$ok) {
  failed <- Filter(function(check) !check$ok, report$checks)
  failures <- vapply(failed, function(check) {
    paste0(
      check$name, ": ",
      paste(unlist(check$problems), collapse = "; ")
    )
  }, character(1))
  stop(
    paste("CAP-Digest conformance failed:", paste(failures, collapse = " | ")),
    call. = FALSE
  )
}

stopifnot(
  verification$ok,
  identical(info$tag, "cap-digest-v1.0.0"),
  report$ok,
  report$level == 3L,
  length(report$checks) == 5L
)
vapply(report$checks, `[[`, logical(1), "ok")

