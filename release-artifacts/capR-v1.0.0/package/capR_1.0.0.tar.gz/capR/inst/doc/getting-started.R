## ----setup, include=FALSE-----------------------------------------------------
knitr::opts_chunk$set(collapse = TRUE, comment = "#>")

## -----------------------------------------------------------------------------
library(capR)

orders <- data.frame(
  order_id = c("A001", "A002"),
  amount = c(12.5, 19),
  api_token = c("sk_test_123", "sk_test_456"),
  check.names = FALSE
)
digest <- cap_digest(orders, budget = 500, label = "orders")
print(digest)
cat(digest$text)

## -----------------------------------------------------------------------------
selected <- vapply(
  Filter(function(row) row$selected, digest$manifest$fields),
  `[[`, character(1), "fieldId"
)
selected
stopifnot(
  "f1:table@shape#base" %in% selected,
  !grepl("sk_test_123", digest$text, fixed = TRUE)
)

