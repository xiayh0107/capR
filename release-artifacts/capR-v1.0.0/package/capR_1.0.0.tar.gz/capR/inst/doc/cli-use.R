## ----setup, include=FALSE-----------------------------------------------------
knitr::opts_chunk$set(collapse = TRUE, comment = "#>")

## -----------------------------------------------------------------------------
library(capR)
script <- system.file("exec", "capr", package = "capR")
stopifnot(file.exists(script))
script

