## ----setup, include=FALSE-----------------------------------------------------
knitr::opts_chunk$set(collapse = TRUE, comment = "#>")

## -----------------------------------------------------------------------------
library(capR)
digest <- cap_digest(data.frame(a = 1:2), budget = 500)
directory <- tempfile()
cap_write_artifacts(digest, directory)
sort(list.files(directory))

reloaded <- cap_read_artifacts(directory)
stopifnot(
  identical(reloaded$text, digest$text),
  identical(
    capr_canonical_json(reloaded$manifest),
    capr_canonical_json(digest$manifest)
  )
)

